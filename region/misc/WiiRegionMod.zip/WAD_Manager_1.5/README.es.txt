+----------------------------+
|   WAD Manager v1.5         |
|   developed by Waninkoko   |
+----------------------------+
|    www.teknoconsolas.es    |
+----------------------------+


[ DISCLAIMER ]:

- ESTA APLICACION VIENE SIN NINGUNA GARANTIA, EXPLICITA NI IMPLICITA.
  NO ME HAGO RESPONSABLE POR CUALQUIER DA�O EN TU CONSOLA WII DEBIDO A
  UN USO NO APROPIADO DE ESTE SOFTWARE.


[ DESCRIPCION ]:

- WAD Manager es una aplicacion que te permite (des)instalar paquetes WAD.

  La aplicacion muestra todos los paquetes WAD disponibles en un
  dispositivo de almacenamiento para poder elegir cual (des)instalar.


[ DISPOSITIVOS SOPORTADOS ]:

- SDGecko.
- Puerto SD interno (con soporte SDHC).
- Dispositivo USB (1.1 y 2.0).


[ COMO USARLO ]:

1. Crea un directorio llamado "wad" en la raiz del dispositivo de almacenamiento.
2. Copia todos los paquetes WAD en el directorio creado en el paso 1.
3. Ejecuta la aplicacion con cualquier metodo para cargar homebrew.


[ NOTAS ]:

- Para poder utilizar la emulacion NAND es necesario tener una copia COMPLETA
  del sistema de ficheros de la NAND en la raiz del dispositivo FAT.


[ KUDOS ]:

- Team Twiizers/devkitPRO
- svpe
- kwiirk
- Todos mis betatesters.
